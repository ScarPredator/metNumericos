# -*- coding: utf-8 -*-
"""
Created on Tue Sep  3 22:47:40 2024

@author: scar
"""

#funcion para calcular el polinomio de Taylor de una funcion


import sympy as sp

x,t=sp.symbols('x,t')
#polinomio de taylor
#resto en valor absoluto
#f funcion
#x0 punto de referencia
#punto que se desea aproximar
#n orden del polinomio de Taylor

def taylor(f,x0,n):
    p=0;
    for i in range (n+1):
        p+=sp.diff(f,x,i).subs(x,x0)/sp.factorial(i)*(x-x0)**i

        r=sp.diff(f,x,n+1).subs(x,t)/sp.factorial(n+1)*(x-x0)**(n+1)

    return p,r

taylor(3*(x**4),4,1)
